Full Dataset Release for SemEval-2 Task #8: Multi-Way Classification of Semantic Relations Between Pairs of Nominals
====================================================================================================================

Iris Hendrickx, Su Nam Kim, Zornitsa Kozareva, Preslav Nakov, Diarmuid Ó Séaghdha, Sebastian Padó, Marco Pennacchiotti, Lorenza Romano and Stan Szpakowicz

The accompanying dataset is released under a Creative Commons Atrribution 3.0 Unported Licence (http://creativecommons.org/licenses/by/3.0/).

This archive contains -- in four separate directories -- the scorer and format tester for SemEval-2 Task #8, and the training data and test data, including the test keys.

Released on July 16, 2010.
