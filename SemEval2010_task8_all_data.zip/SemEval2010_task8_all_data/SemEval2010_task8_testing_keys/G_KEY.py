fname = '/home/pengda/OpenWordRE/Dataset/ori/SemEval2010_task8_all_data/SemEval2010_task8_testing_keys/TEST_FILE_FULL.TXT'
fin = open(fname).readlines()
fout = open("./TEST_KEY_19.TXT", 'w')

for num in range(2717):
	id = fin[4*num+0].split('\t')[0]
	answer = fin[4*num+1].strip()
	fout.write(str(id)+'\t'+answer+'\n')
	
